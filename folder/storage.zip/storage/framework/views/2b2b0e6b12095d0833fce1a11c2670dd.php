<?php $__env->startSection('title', 'Checkout page'); ?>

<?php $__env->startSection('main-content'); ?>

    <!-- Start Checkout -->
    <section class="checkout-section py-5">
        <div class="container">
            <form class="checkout-form" method="POST" action="<?php echo e(route('cart.order')); ?>">
                <?php echo csrf_field(); ?>
                <div class="row g-4">
                    <div class="col-lg-8">
                        <div class="card shadow-sm border-0 h-100">
                            <div class="card-body p-4">
                                <h2 class="card-title fw-bold mb-2">Checkout Disini</h2>
                                <p class="text-muted mb-4">Mohon Register agar dapat checkout lebih cepat</p>

                                <div class="row g-3">
                                    <div class="col-md-6">
                                        <div class="mb-3">
                                            <label for="firstName" class="form-label">Nama Depan<span
                                                    class="text-danger">*</span></label>
                                            <input type="text" class="form-control" id="firstName" name="first_name"
                                                value="<?php echo e(old('first_name')); ?>">
                                            <?php $__errorArgs = ['first_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="text-danger mt-1"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="mb-3">
                                            <label for="lastName" class="form-label">Nama Belakang<span
                                                    class="text-danger">*</span></label>
                                            <input type="text" class="form-control" id="lastName" name="last_name"
                                                value="<?php echo e(old('lat_name')); ?>">
                                            <?php $__errorArgs = ['last_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="text-danger mt-1"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="mb-3">
                                            <label for="email" class="form-label">Alamat Email<span
                                                    class="text-danger">*</span></label>
                                            <input type="email" class="form-control" id="email" name="email"
                                                value="<?php echo e(old('email')); ?>">
                                            <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="text-danger mt-1"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="mb-3">
                                            <label for="phone" class="form-label">Nomor HP<span
                                                    class="text-danger">*</span></label>
                                            <input type="number" class="form-control" id="phone" name="phone"
                                                required value="<?php echo e(old('phone')); ?>">
                                            <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="text-danger mt-1"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="mb-3">
                                            <label for="country" class="form-label">Negara<span
                                                    class="text-danger">*</span></label>
                                            <select name="country" id="country">
                                                <option value="ID">Indonesia</option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="mb-3">
                                            <label for="address1" class="form-label">Alamat 1<span
                                                    class="text-danger">*</span></label>
                                            <input type="text" class="form-control" id="address1" name="address1"
                                                value="<?php echo e(old('address1')); ?>">
                                            <?php $__errorArgs = ['address1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="text-danger mt-1"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="mb-3">
                                            <label for="address2" class="form-label">Alamat 2</label>
                                            <input type="text" class="form-control" id="address2" name="address2"
                                                value="<?php echo e(old('address2')); ?>">
                                            <?php $__errorArgs = ['address2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="text-danger mt-1"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="mb-3">
                                            <label for="postCode" class="form-label">Kode Pos</label>
                                            <input type="text" class="form-control" id="postCode" name="post_code"
                                                value="<?php echo e(old('post_code')); ?>">
                                            <?php $__errorArgs = ['post_code'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                <div class="text-danger mt-1"><?php echo e($message); ?></div>
                                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="col-lg-4">
                        <div class="card shadow-sm border-0">
                            <div class="card-body p-4">
                                <h2 class="card-title fs-4 fw-bold mb-3">Total Keranjang</h2>
                                <div class="d-flex justify-content-between mb-2">
                                    <span class="fw-medium">Subtotal Keranjang</span>
                                    <span class="fw-bold order_subtotal" data-price="<?php echo e(Helper::totalCartPrice()); ?>">
                                        Rp <?php echo e(number_format(Helper::totalCartPrice(), 0, ',', '.')); ?>

                                    </span>
                                </div>

                                <div class="mb-3">
                                    <div class="d-flex justify-content-between">
                                        <span class="fw-medium">Biaya Pengiriman</span>
                                        <?php if(count(Helper::shipping()) > 0 && Helper::cartCount() > 0): ?>
                                            <div class="shipping-select w-50">
                                                <select name="shipping" class="form-select form-select-sm">
                                                    <option value="">Pilih Pengiriman</option>
                                                    <?php $__currentLoopData = Helper::shipping(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $shipping): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($shipping->id); ?>" class="shippingOption"
                                                            data-price="<?php echo e($shipping->price); ?>">
                                                            <?php echo e($shipping->type); ?>: Rp
                                                            <?php echo e(number_format($shipping->price, 0, ',', '.')); ?>

                                                        </option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                            </div>
                                        <?php else: ?>
                                            <span>Gratis</span>
                                        <?php endif; ?>
                                    </div>
                                </div>

                                <?php if(session('coupon')): ?>
                                    <div class="d-flex justify-content-between mb-2">
                                        <span class="fw-medium">Kamu hemat</span>
                                        <span class="text-success coupon_price"
                                            data-price="<?php echo e(session('coupon')['value']); ?>">
                                            Rp <?php echo e(number_format(session('coupon')['value'], 0, ',', '.')); ?>

                                        </span>
                                    </div>
                                <?php endif; ?>

                                <?php
                                    $total_amount = Helper::totalCartPrice();
                                    if (session('coupon')) {
                                        $total_amount = $total_amount - session('coupon')['value'];
                                    }
                                ?>

                                <div class="d-flex justify-content-between border-top pt-3 mt-3">
                                    <span class="fw-bold fs-5">Total</span>
                                    <span class="fw-bold fs-5" id="order_total_price">
                                        Rp <?php echo e(number_format($total_amount, 0, ',', '.')); ?>

                                    </span>
                                </div>
                            </div>


                            <div class="card-body border-top p-4">
                                <h2 class="card-title fs-4 fw-bold mb-3">Metode Pembayaran</h2>
                                <div class="form-check mb-2">
                                    <input class="form-check-input" type="radio" name="payment_method" id="cod"
                                        value="cod">
                                    <label class="form-check-label" for="cod">Cash On Delivery</label>
                                </div>
                                <div class="form-check">
                                    <input class="form-check-input" type="radio" name="payment_method" id="paypal"
                                        value="paypal">
                                    <label class="form-check-label" for="midtrans">Midtrans</label>
                                </div>
                            </div>

                            <div class="card-body border-top p-4">
                                <div class="text-center mb-3">
                                    <img src="<?php echo e('backend/img/payment-method.png'); ?>" alt="Payment Methods"
                                        class="img-fluid">
                                </div>
                                <button type="submit" class="btn btn-primary w-100 py-2 fw-bold">CHECKOUT</button>
                            </div>
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </section>
    <!--/ End Checkout -->

    <!-- Start Area Layanan Toko -->
    <section class="shop-services section py-5">
        <div class="container">
            <div class="row gap-3 gap-lg-0">
                <div class="col-lg-3 col-md-6 col-12">
                    <!-- Start Layanan Tunggal -->
                    <div class="single-service text-center p-4 border rounded shadow-sm">
                        <i class="fas fa-shipping-fast mb-3"></i>
                        <h4>Pengiriman Gratis</h4>
                        <p>Pesanan di atas Rp 50.000</p>
                    </div>
                    <!-- End Layanan Tunggal -->
                </div>
                <div class="col-lg-3 col-md-6 col-12">
                    <!-- Start Layanan Tunggal -->
                    <div class="single-service text-center p-4 border rounded shadow-sm">
                        <i class="fas fa-undo-alt mb-3"></i>
                        <h4>Pengembalian Gratis</h4>
                        <p>Pengembalian dalam 30 hari</p>
                    </div>
                    <!-- End Layanan Tunggal -->
                </div>
                <div class="col-lg-3 col-md-6 col-12">
                    <!-- Start Layanan Tunggal -->
                    <div class="single-service text-center p-4 border rounded shadow-sm">
                        <i class="fas fa-lock mb-3"></i>
                        <h4>Pembayaran Aman</h4>
                        <p>Pembayaran 100% aman</p>
                    </div>
                    <!-- End Layanan Tunggal -->
                </div>
                <div class="col-lg-3 col-md-6 col-12">
                    <!-- Start Layanan Tunggal -->
                    <div class="single-service text-center p-4 border rounded shadow-sm">
                        <i class="fas fa-tag mb-3"></i>
                        <h4>Harga Terbaik</h4>
                        <p>Harga yang dijamin</p>
                    </div>
                    <!-- End Layanan Tunggal -->
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <script>
        $(document).ready(function() {
            // Update total when shipping option changes
            $('select[name=shipping]').change(function() {
                let cost = parseFloat($(this).find('option:selected').data('price')) || 0;
                let subtotal = parseFloat($('.order_subtotal').data('price'));
                let coupon = parseFloat($('.coupon_price').data('price')) || 0;

                // Hitung total
                let total = subtotal + cost - coupon;

                // Update total di tampilan
                $('#order_total_price').text('Rp ' + number_format(total, 0, ',', '.'));
            });
        });

        // Fungsi untuk format angka
        function number_format(number, decimals, dec_point, thousands_sep) {
            // Default values
            decimals = decimals || 0;
            dec_point = dec_point || '.';
            thousands_sep = thousands_sep || ',';

            number = parseFloat(number);
            if (isNaN(number)) return '0';

            // Format number
            let parts = number.toFixed(decimals).split('.');
            parts[0] = parts[0].replace(/\B(?=(\d{3})+(?!\d))/g, thousands_sep);
            return parts.join(dec_point);
        }
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('frontend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/rioanggoro/Documents/kerjaan/ecomerce-laravel-fashion/resources/views/frontend/pages/checkout.blade.php ENDPATH**/ ?>
<?php $__env->startSection('title', 'Cart Page'); ?>
<?php $__env->startSection('main-content'); ?>

    <!-- Shopping Cart -->
    <div class="shopping-cart section">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <!-- Shopping Summery -->
                    <div class="table-responsive">
                        <table class="table shopping-summery">
                            <thead>
                                <tr class="main-heading">
                                    <th>Produk</th>
                                    <th>Nama</th>
                                    <th class="text-center">Harga Unit</th>
                                    <th class="text-center">Qty</th>
                                    <th class="text-center">Size</th>
                                    <th class="text-center">Total</th>
                                    <th class="text-center"><i class="fa fa-trash remove-icon"></i></th>
                                </tr>
                            </thead>
                            <tbody id="cart_item_list">
                                <form action="<?php echo e(route('cart.update')); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <?php if(Helper::getAllProductFromCart()): ?>
                                        <?php $__currentLoopData = Helper::getAllProductFromCart(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $cart): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <?php
                                                    $photo = explode(',', $cart->product['photo']);
                                                ?>
                                                <td class="image" data-title="No">
                                                    <img src="<?php echo e($photo[0]); ?>" class="img-fluid rounded"
                                                        style="max-height: 100px" alt="<?php echo e($photo[0]); ?>">
                                                </td>
                                                <td class="product-des" data-title="Description">
                                                    <p class="product-name">
                                                        <a href="<?php echo e(route('product-detail', $cart->product['slug'])); ?>"
                                                            target="_blank">
                                                            <?php echo e($cart->product['title']); ?>

                                                        </a>
                                                    </p>
                                                    <p class="product-des"><?php echo $cart['summary']; ?></p>
                                                </td>
                                                <td class="price" data-title="Price">
                                                    <span>Rp<?php echo e(number_format($cart['price'], 2)); ?></span>
                                                </td>
                                                <td class="qty" data-title="Qty">
                                                    <!-- Input Order -->
                                                    <div class="d-flex gap-2">
                                                        <div class="button minus">
                                                            <button type="button" class="btn btn-primary btn-number"
                                                                disabled="disabled" data-type="minus"
                                                                data-field="quant[<?php echo e($key); ?>]">
                                                                <i class="fa fa-minus"></i>
                                                            </button>
                                                        </div>
                                                        <input type="text" name="quant[<?php echo e($key); ?>]"
                                                            class="rounded px-2" data-min="1" data-max="100"
                                                            value="<?php echo e($cart->quantity); ?>">
                                                        <input type="hidden" name="qty_id[]" value="<?php echo e($cart->id); ?>">
                                                        <div class="button plus">
                                                            <button type="button" class="btn btn-primary btn-number"
                                                                data-type="plus" data-field="quant[<?php echo e($key); ?>]">
                                                                <i class="fa fa-plus"></i>
                                                            </button>
                                                        </div>
                                                    </div>
                                                    <!--/ End Input Order -->
                                                </td>
                                                <td class="text-center" data-title="Size">
                                                    <span class="text-capitalize"><?php echo e($cart['size']); ?></span>
                                                </td>
                                                <td class="total-amount cart_single_price" data-title="Total">
                                                    <span class="money">Rp<?php echo e($cart['amount']); ?></span>
                                                </td>
                                                <td class="action text-center" data-title="Remove">
                                                    <a href="<?php echo e(route('cart-delete', $cart->id)); ?>">
                                                        <i class="fa fa-trash text-danger"></i>
                                                    </a>
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td colspan="5"></td>
                                            <td class="float-right">
                                                <button class="btn btn-primary" type="submit">Update</button>
                                            </td>
                                        </tr>
                                    <?php else: ?>
                                        <tr>
                                            <td class="text-center" colspan="6">
                                                Belum ada produk di keranjang
                                                <a href="<?php echo e(route('product-grids')); ?>" class="text-primary">Lanjut
                                                    Belanja</a>
                                            </td>
                                        </tr>
                                    <?php endif; ?>
                                </form>
                            </tbody>
                        </table>
                    </div>
                    <!--/ End Shopping Summery -->
                </div>
            </div>

            <div class="row">
                <div class="col-12">
                    <!-- Total Amount -->
                    <div class="total-amount">
                        <div class="row">
                            <div class="col-lg-8 col-md-5 col-12">
                                <div class="left">
                                    <div class="coupon">
                                        <form action="<?php echo e(route('coupon-store')); ?>" method="POST">
                                            <?php echo csrf_field(); ?>
                                            <input name="code" class="form-control" placeholder="Masukkan kode kupon"
                                                type="text">
                                            <button class="btn btn-secondary mt-3" type="submit">Apply</button>
                                        </form>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-4 col-md-7 col-12">
                                <div class="right">
                                    <ul class="list-unstyled">
                                        <li class="order_subtotal" data-price="<?php echo e(Helper::totalCartPrice()); ?>">
                                            Subtotal <span>Rp<?php echo e(number_format(Helper::totalCartPrice(), 2)); ?></span>
                                        </li>

                                        <?php if(session()->has('coupon')): ?>
                                            <li class="coupon_price" data-price="<?php echo e(Session::get('coupon')['value']); ?>">
                                                Kamu hemat
                                                <span>Rp<?php echo e(number_format(Session::get('coupon')['value'], 2)); ?></span>
                                            </li>
                                        <?php endif; ?>

                                        <?php
                                            $total_amount = Helper::totalCartPrice();
                                            if (session()->has('coupon')) {
                                                $total_amount = $total_amount - Session::get('coupon')['value'];
                                            }
                                        ?>
                                        <li class="last" id="order_total_price">
                                            Total <span>Rp<?php echo e(number_format($total_amount, 2)); ?></span>
                                        </li>
                                    </ul>
                                    <div class="button5">
                                        <a href="<?php echo e(route('checkout')); ?>" class="btn btn-dark">Checkout <i
                                                class="fa fa-long-arrow-right"></i></a>
                                        <a href="<?php echo e(route('product-grids')); ?>" class="btn btn-secondary">Lanjut
                                            Belanja</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!--/ End Total Amount -->
                </div>
            </div>
        </div>
    </div>
    <!--/ End Shopping Cart -->

    <!-- Start Area Layanan Toko -->
    <section class="shop-services section py-5">
        <div class="container">
            <div class="row gap-3 gap-lg-0">
                <div class="col-lg-3 col-md-6 col-12">
                    <!-- Start Layanan Tunggal -->
                    <div class="single-service text-center p-4 border rounded shadow-sm">
                        <i class="fas fa-shipping-fast mb-3"></i>
                        <h4>Pengiriman Gratis</h4>
                        <p>Pesanan di atas Rp 50.000</p>
                    </div>
                    <!-- End Layanan Tunggal -->
                </div>
                <div class="col-lg-3 col-md-6 col-12">
                    <!-- Start Layanan Tunggal -->
                    <div class="single-service text-center p-4 border rounded shadow-sm">
                        <i class="fas fa-undo-alt mb-3"></i>
                        <h4>Pengembalian Gratis</h4>
                        <p>Pengembalian dalam 30 hari</p>
                    </div>
                    <!-- End Layanan Tunggal -->
                </div>
                <div class="col-lg-3 col-md-6 col-12">
                    <!-- Start Layanan Tunggal -->
                    <div class="single-service text-center p-4 border rounded shadow-sm">
                        <i class="fas fa-lock mb-3"></i>
                        <h4>Pembayaran Aman</h4>
                        <p>Pembayaran 100% aman</p>
                    </div>
                    <!-- End Layanan Tunggal -->
                </div>
                <div class="col-lg-3 col-md-6 col-12">
                    <!-- Start Layanan Tunggal -->
                    <div class="single-service text-center p-4 border rounded shadow-sm">
                        <i class="fas fa-tag mb-3"></i>
                        <h4>Harga Terbaik</h4>
                        <p>Harga yang dijamin</p>
                    </div>
                    <!-- End Layanan Tunggal -->
                </div>
            </div>
        </div>
    </section>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('styles'); ?>
    <style>
        .form-select .nice-select {
            border: none;
            border-radius: 0;
            height: 40px;
            background: #f6f6f6 !important;
            padding-left: 45px;
            padding-right: 40px;
        }

        .list li {
            margin-bottom: 0 !important;
        }

        .list li:hover {
            background: #F7941D !important;
            color: white !important;
        }

        /* Responsive Adjustments */
        @media (max-width: 768px) {

            .shopping-summery th,
            .shopping-summery td {
                font-size: 12px;
            }

            .shopping-summery td .product-des {
                max-width: 100px;
                white-space: nowrap;
                overflow: hidden;
                text-overflow: ellipsis;
            }

            .total-amount .right ul {
                font-size: 14px;
            }

            .input-group {
                flex-direction: column;
            }

            .button {
                width: 100%;
                text-align: center;
            }

            .button5 {
                display: flex;
                flex-direction: column;
            }

            .button5 a {
                margin-bottom: 10px;
            }
        }

        /* For Mobile */
        @media (max-width: 576px) {
            .shopping-summery td .product-des {
                display: none;
            }

            .shopping-summery td .price,
            .shopping-summery td .qty {
                text-align: center;
            }
        }
    </style>
<?php $__env->stopPush(); ?>

<?php $__env->startPush('scripts'); ?>
    <script>
        $(document).ready(function() {
            $("select.select2").select2();
            $('select.nice-select').niceSelect();
        });

        $(document).ready(function() {
            $('.shipping select[name=shipping]').change(function() {
                let cost = parseFloat($(this).find('option:selected').data('price')) || 0;
                let subtotal = parseFloat($('.order_subtotal').data('price'));
                let coupon = parseFloat($('.coupon_price').data('price')) || 0;
                $('#order_total_price span').text('$' + (subtotal + cost - coupon).toFixed(2));
            });
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('frontend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/rioanggoro/Documents/kerjaan/ecomerce-laravel-fashion/resources/views/frontend/pages/cart.blade.php ENDPATH**/ ?>
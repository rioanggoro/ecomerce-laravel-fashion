<?php $__env->startSection('title', 'E-SHOP || HOME PAGE'); ?>

<?php $__env->startSection('main-content'); ?>
    <?php if(count($banners) > 0): ?>
        <div id="heroCarousel" class="carousel slide" data-bs-ride="carousel" data-bs-interval="4000">
            <div class="carousel-indicators">
                <?php $__currentLoopData = $banners; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $banner): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <button type="button" data-bs-target="#heroCarousel" data-bs-slide-to="<?php echo e($key); ?>" class="<?php echo e($key == 0 ? 'active' : ''); ?>" aria-current="<?php echo e($key == 0 ? 'true' : 'false'); ?>" aria-label="Slide <?php echo e($key+1); ?>"></button>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <div class="carousel-inner">
                <?php $__currentLoopData = $banners; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $banner): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="carousel-item <?php echo e($key == 0 ? 'active' : ''); ?>">
                        <div class="carousel-image-container position-relative">
                            <img src="<?php echo e($banner->photo); ?>" class="d-block w-100 h-auto" alt="<?php echo e($banner->title); ?>">
                            <div class="carousel-overlay position-absolute top-0 start-0 w-100 h-100 bg-dark opacity-25"></div>
                        </div>
                        <div class="carousel-caption d-none d-md-block position-absolute top-50 start-50 translate-middle">
                            <h1><?php echo e($banner->title); ?></h1>
                            <p><?php echo html_entity_decode($banner->description); ?></p>
                            <a class="btn btn-lg ws-btn" href="<?php echo e(route('product-grids')); ?>" role="button">Shop Now <i class="far fa-arrow-alt-circle-right"></i></a>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <button class="carousel-control-prev" type="button" data-bs-target="#heroCarousel" data-bs-slide="prev">
                <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                <span class="visually-hidden">Previous</span>
            </button>
            <button class="carousel-control-next" type="button" data-bs-target="#heroCarousel" data-bs-slide="next">
                <span class="carousel-control-next-icon" aria-hidden="true"></span>
                <span class="visually-hidden">Next</span>
            </button>
        </div>
    <?php endif; ?>

    <!-- All Products Section -->
    <section class="all-products py-5">
        <div class="container">
            <div class="d-md-flex text-center justify-content-between align-items-center mb-5">
                <h2 >Pilihan Gaya Untuk Kamu</h2>
                <a href="<?php echo e(route('product-grids')); ?>" class="text-decoration-none">Lihat Semua</a>
            </div>
            <div class="row">
                <?php if(count($product_lists)): ?>
                    <?php $__currentLoopData = $product_lists; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-lg-3 col-md-4 col-sm-6 product-item mb-4" data-category="<?php echo e($data->cat_id); ?>">
                            <div class="card h-100">
                                <?php
                                    $photo = explode(',', $data->photo);
                                ?>
                                <a href="<?php echo e(route('product-detail', $data->slug)); ?>">
                                    <img src="<?php echo e($photo[0]); ?>" class="card-img-top" alt="<?php echo e($photo[0]); ?>">
                                </a>
                                <div class="card-body text-center">
                                    <h5 class="card-title">
                                        <a href="<?php echo e(route('product-detail', $data->slug)); ?>" class="text-decoration-none text-dark"><?php echo e($data->title); ?></a>
                                    </h5>
                                    <p class="text-muted">
                                        <span class="text-decoration-line-through">Rp<?php echo e(number_format($data->price, 2)); ?></span>
                                        <span class="fw-bold text-danger">Rp<?php echo e(number_format($data->price - (($data->discount * $data->price) / 100), 2)); ?></span>
                                    </p>
                                    <div class="btn-group" role="group">
                                        <a href="<?php echo e(route('add-to-wishlist', $data->slug)); ?>" class="btn btn-outline-danger"><i class="fa fa-heart"></i></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php else: ?>
                    <h4 class="text-warning text-center w-100">No products found.</h4>
                <?php endif; ?>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/rioanggoro/Documents/kerjaan/ecomerce-laravel-fashion/resources/views/frontend/index.blade.php ENDPATH**/ ?>
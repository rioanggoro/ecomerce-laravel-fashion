<?php $__env->startSection('meta'); ?>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name='copyright' content=''>
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="keywords" content="online shop, purchase, cart, ecommerce site, best online shopping">
    <meta name="description" content="<?php echo e($product_detail->summary); ?>">
    <meta property="og:url" content="<?php echo e(route('product-detail', $product_detail->slug)); ?>">
    <meta property="og:type" content="article">
    <meta property="og:title" content="<?php echo e($product_detail->title); ?>">
    <meta property="og:image" content="<?php echo e($product_detail->photo); ?>">
    <meta property="og:description" content="<?php echo e($product_detail->description); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('title', 'E-SHOP || PRODUCT DETAIL'); ?>

<?php $__env->startSection('main-content'); ?>

    <div class="container mb-5">
        <div class="row align-items-start">
            <!-- Product Description Column -->
            <div class="col-md-3">
                <h2><?php echo e($product_detail->title); ?></h2>
                <div class="d-flex align-items-center mb-3">
                    <div class="rating me-2">
                        <?php
                            $rate = ceil($product_detail->getReview->avg('rate'));
                        ?>
                        <?php for($i = 1; $i <= 5; $i++): ?>
                            <?php if($rate >= $i): ?>
                                <i class="fa fa-star text-warning"></i>
                            <?php else: ?>
                                <i class="fa fa-star-o text-warning"></i>
                            <?php endif; ?>
                        <?php endfor; ?>
                    </div>
                </div>
                <p><?php echo $product_detail->summary; ?></p>
            </div>

            <!-- Product Image Column -->
            <div class="col-md-5">
                <div class="row">
                    <?php
                        $photo = explode(',', $product_detail->photo);
                    ?>
                    <div class="carousel-thumbnails d-none d-md-flex flex-column gap-2 col-md-2 hidden-md">
                        <?php $__currentLoopData = $photo; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $img): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <img src="<?php echo e($img); ?>" alt="Thumbnail <?php echo e($key + 1); ?>" class="img-thumbnail mb-2"
                                data-bs-target="#productCarousel" data-bs-slide-to="<?php echo e($key); ?>"
                                <?php if($key == 0): ?> class="active" <?php endif; ?>>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <div id="productCarousel" class="carousel slide col-md-10" data-bs-ride="carousel">
                        <div class="carousel-inner">
                            <?php $__currentLoopData = $photo; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $img): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="carousel-item <?php if($key == 0): ?> active <?php endif; ?>">
                                    <img src="<?php echo e($img); ?>" class="d-block w-100" alt="Product <?php echo e($key + 1); ?>">
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                        <button class="carousel-control-prev" type="button" data-bs-target="#productCarousel"
                            data-bs-slide="prev">
                            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                            <span class="visually-hidden">Previous</span>
                        </button>
                        <button class="carousel-control-next" type="button" data-bs-target="#productCarousel"
                            data-bs-slide="next">
                            <span class="carousel-control-next-icon" aria-hidden="true"></span>
                            <span class="visually-hidden">Next</span>
                        </button>
                    </div>
                </div>
            </div>

            <!-- Product Details Column -->
            <div class="col-md-4">
                <?php
                    $after_discount =
                        $product_detail->price - ($product_detail->price * $product_detail->discount) / 100;
                ?>
                <h3 class="mb-2">Rp<?php echo e(number_format($after_discount, 2)); ?></h3>
                <?php if($product_detail->discount > 0): ?>
                    <p><s class="text-muted">Rp<?php echo e(number_format($product_detail->price, 2)); ?></s>
                        <span class="badge bg-danger"><?php echo e($product_detail->discount); ?>% OFF</span>
                    </p>
                <?php endif; ?>

                <?php if($product_detail->size): ?>
                    <h5 class="mt-4">UKURAN</h5>
                    <div class="d-flex flex-wrap gap-2 my-4">
                        <?php
                            $sizes = explode(',', $product_detail->size);
                        ?>
                        <?php $__currentLoopData = $sizes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $size): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-3 text-center border rounded p-2"><?php echo e($size); ?></div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                <?php endif; ?>

                <form action="<?php echo e(route('single-add-to-cart')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="slug" value="<?php echo e($product_detail->slug); ?>">

                    <div class="mb-4">
                        <h5>Quantity:</h5>
                        <div class="input-group">
                            <button type="button" class="btn btn-outline-secondary" id="decrement">
                                <i class="fa fa-minus"></i>
                            </button>
                            <input type="text" name="quant[1]" class="form-control text-center" value="1"
                                id="quantity" min="1" max="<?php echo e($product_detail->stock); ?>">
                            <button type="button" class="btn btn-outline-secondary" id="increment">
                                <i class="fa fa-plus"></i>
                            </button>
                        </div>
                    </div>

                    <div>
                        <h6>
                            Kategori:
                            <span class="fw-normal">
                                <a href="<?php echo e(route('product-cat', $product_detail->cat_info['slug'])); ?>"
                                    class="text-decoration-none">
                                    <?php echo e($product_detail->cat_info['title']); ?>

                                </a>
                            </span>
                        </h6>
                        <?php if($product_detail->sub_cat_info): ?>
                            <h6>
                                Sub Kategori:
                                <span class="fw-normal">
                                    <a href="<?php echo e(route('product-sub-cat', [$product_detail->cat_info['slug'], $product_detail->sub_cat_info['slug']])); ?>"
                                        class="text-decoration-none">
                                        <?php echo e($product_detail->sub_cat_info['title']); ?>

                                    </a>
                                </span>
                            </h6>
                        <?php endif; ?>
                        <h6>
                            Stock:
                            <?php if($product_detail->stock > 0): ?>
                                <span class="badge bg-success"><?php echo e($product_detail->stock); ?></span>
                            <?php else: ?>
                                <span class="badge bg-danger">Stok Habis</span>
                            <?php endif; ?>
                        </h6>
                    </div>

                    <div class="d-grid gap-2 mt-4">
                        <button type="submit" class="btn btn-dark">
                            <i class="fa fa-shopping-cart"></i> Tambah ke Keranjang
                        </button>
                        <a href="<?php echo e(route('add-to-wishlist', $product_detail->slug)); ?>" class="btn btn-outline-danger">
                            <i class="fa fa-heart"></i> Tambah ke Favorit
                        </a>
                    </div>
                </form>
            </div>
        </div>

        <!-- Product Description Tabs -->
        <div class="row mt-5">
            <div class="col-12">
                <ul class="nav nav-tabs" id="productTabs" role="tablist">
                    <li class="nav-item" role="presentation">
                        <button class="nav-link active" id="description-tab" data-bs-toggle="tab"
                            data-bs-target="#description" type="button" role="tab" aria-controls="description"
                            aria-selected="true">Deskripsi</button>
                    </li>
                    <li class="nav-item" role="presentation">
                        <button class="nav-link" id="reviews-tab" data-bs-toggle="tab" data-bs-target="#reviews"
                            type="button" role="tab" aria-controls="reviews" aria-selected="false">Ulasan</button>
                    </li>
                </ul>
                <div class="tab-content p-4 border border-top-0 rounded-bottom" id="productTabsContent">
                    <div class="tab-pane fade show active" id="description" role="tabpanel"
                        aria-labelledby="description-tab">
                        <?php echo $product_detail->description; ?>

                    </div>
                    <div class="tab-pane fade" id="reviews" role="tabpanel" aria-labelledby="reviews-tab">
                        <!-- Reviews Summary -->
                        <div class="mb-4">
                            <h4>Ringkasan Rating</h4>
                            <div class="d-flex align-items-center">
                                <h2 class="me-3 mb-0"><?php echo e(ceil($product_detail->getReview->avg('rate'))); ?>/5</h2>
                                <div>
                                    <div class="rating">
                                        <?php for($i = 1; $i <= 5; $i++): ?>
                                            <?php if(ceil($product_detail->getReview->avg('rate')) >= $i): ?>
                                                <i class="fa fa-star text-warning"></i>
                                            <?php else: ?>
                                                <i class="fa fa-star-o text-warning"></i>
                                            <?php endif; ?>
                                        <?php endfor; ?>
                                    </div>
                                    <p class="mb-0">Berdasarkan <?php echo e($product_detail->getReview->count()); ?> ulasan</p>
                                </div>
                            </div>
                        </div>

                        <!-- Review Form -->
                        <div class="card mb-4">
                            <div class="card-header">
                                <h5 class="mb-0">Tulis Ulasan</h5>
                            </div>
                            <div class="card-body">
                                <?php if(auth()->guard()->check()): ?>
                                    <form action="<?php echo e(route('review.store', $product_detail->slug)); ?>" method="post">
                                        <?php echo csrf_field(); ?>
                                        <div class="mb-3">
                                            <label class="form-label">Rating</label>
                                            <div class="rating-box">
                                                <div class="star-rating">
                                                    <div class="star-rating__wrap">
                                                        <input class="star-rating__input" id="star-rating-5" type="radio"
                                                            name="rate" value="5">
                                                        <label class="star-rating__ico fa fa-star-o" for="star-rating-5"
                                                            title="5 out of 5 stars"></label>
                                                        <input class="star-rating__input" id="star-rating-4" type="radio"
                                                            name="rate" value="4">
                                                        <label class="star-rating__ico fa fa-star-o" for="star-rating-4"
                                                            title="4 out of 5 stars"></label>
                                                        <input class="star-rating__input" id="star-rating-3" type="radio"
                                                            name="rate" value="3">
                                                        <label class="star-rating__ico fa fa-star-o" for="star-rating-3"
                                                            title="3 out of 5 stars"></label>
                                                        <input class="star-rating__input" id="star-rating-2" type="radio"
                                                            name="rate" value="2">
                                                        <label class="star-rating__ico fa fa-star-o" for="star-rating-2"
                                                            title="2 out of 5 stars"></label>
                                                        <input class="star-rating__input" id="star-rating-1" type="radio"
                                                            name="rate" value="1">
                                                        <label class="star-rating__ico fa fa-star-o" for="star-rating-1"
                                                            title="1 out of 5 stars"></label>
                                                    </div>
                                                </div>
                                                <?php $__errorArgs = ['rate'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <span class="text-danger"><?php echo e($message); ?></span>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                        </div>
                                        <div class="mb-3">
                                            <label for="review" class="form-label">Ulasan Anda</label>
                                            <textarea class="form-control" id="review" name="review" rows="3" required></textarea>
                                        </div>
                                        <button type="submit" class="btn btn-dark">Submit Ulasan</button>
                                    </form>
                                <?php else: ?>
                                    <div class="text-center py-4">
                                        <p>You need to <a href="<?php echo e(route('login.form')); ?>"
                                                class="text-decoration-none">Login</a> or
                                            <a href="<?php echo e(route('register.form')); ?>" class="text-decoration-none">Register</a>
                                            to write a review
                                        </p>
                                    </div>
                                <?php endif; ?>
                            </div>
                        </div>

                        <!-- Customer Reviews -->
                        <div class="customer-reviews">
                            <h4 class="mb-4">Ulasan Customer</h4>
                            <?php $__currentLoopData = $product_detail['getReview']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $review): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="card mb-3">
                                    <div class="card-body">
                                        <div class="d-flex mb-3">
                                            <div class="flex-shrink-0">
                                                <?php if($review->user_info['photo']): ?>
                                                    <img src="<?php echo e($review->user_info['photo']); ?>"
                                                        alt="<?php echo e($review->user_info['name']); ?>" class="rounded-circle"
                                                        width="50" height="50">
                                                <?php else: ?>
                                                    <img src="<?php echo e(asset('backend/img/avatar.png')); ?>" alt="Profile"
                                                        class="rounded-circle" width="50" height="50">
                                                <?php endif; ?>
                                            </div>
                                            <div class="flex-grow-1 ms-3">
                                                <h5 class="mb-1"><?php echo e($review->user_info['name']); ?></h5>
                                                <div class="rating">
                                                    <?php for($i = 1; $i <= 5; $i++): ?>
                                                        <?php if($review->rate >= $i): ?>
                                                            <i class="fa fa-star text-warning"></i>
                                                        <?php else: ?>
                                                            <i class="fa fa-star-o text-warning"></i>
                                                        <?php endif; ?>
                                                    <?php endfor; ?>
                                                </div>
                                            </div>
                                        </div>
                                        <p class="mb-0"><?php echo e($review->review); ?></p>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="container py-5">
            <div class="row">
                <div class="col-12 mb-4">
                    <h2>Rekomendasi Untuk Kamu</h2>
                </div>
            </div>
            <div class="row row-cols-1 row-cols-md-2 row-cols-lg-4 g-4">
                <?php $__currentLoopData = $product_detail->rel_prods; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php if($data->id !== $product_detail->id): ?>
                        <div class="col">
                            <div class="card text-center h-100">
                                <?php
                                    $photo = explode(',', $data->photo);
                                ?>
                                <a href="<?php echo e(route('product-detail', $data->slug)); ?>">
                                    <img src="<?php echo e($photo[0]); ?>" class="card-img-top img-fluid"
                                        alt="<?php echo e($photo[0]); ?>">
                                </a>
                                <div class="card-body">
                                    <h5 class="card-title">
                                        <a class="text-decoration-none text-dark"
                                            href="<?php echo e(route('product-detail', $data->slug)); ?>"><?php echo e($data->title); ?></a>
                                    </h5>
                                    <p class="text-muted">
                                        <span
                                            class="text-decoration-line-through">Rp<?php echo e(number_format($data->price, 2)); ?></span>
                                        <span
                                            class="fw-bold text-danger">Rp<?php echo e(number_format($data->price - ($data->discount * $data->price) / 100, 2)); ?></span>
                                    </p>
                                    <div class="btn-group" role="group">
                                        <a href="<?php echo e(route('add-to-wishlist', $data->slug)); ?>"
                                            class="btn btn-outline-danger"><i class="fa fa-heart"></i></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
    </section>

<?php $__env->stopSection(); ?>


<?php $__env->startPush('scripts'); ?>
    <script>
        // script for add and minus
        const decrement = document.getElementById('decrement');
        const increment = document.getElementById('increment');
        const quantity = document.getElementById('quantity');
        decrement.addEventListener('click', function() {
            if (quantity.value > 1) {
                quantity.value--;
            }
        });
        increment.addEventListener('click', function() {
            quantity.value++;
        });
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('frontend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/rioanggoro/Documents/kerjaan/ecomerce-laravel-fashion/resources/views/frontend/pages/product_detail.blade.php ENDPATH**/ ?>
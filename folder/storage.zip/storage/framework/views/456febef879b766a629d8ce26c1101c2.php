<nav class="navbar navbar-expand-lg navbar-light bg-white shadow-sm">
    <div class="container">
        <a class="navbar-brand fw-bold" href="<?php echo e(route('home')); ?>">
            <img src="<?php echo e(asset('backend/img/logo_primary.png')); ?>" alt="Logo Prolific" class="logo-img">
        </a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav"
            aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                <li class="nav-item"><a class="nav-link" href="<?php echo e(route('product-grids')); ?>">Toko</a></li>
                <li class="nav-item"><a class="nav-link" href="<?php echo e(route('about-us')); ?>">Tentang Kami</a></li>
            </ul>
            <ul class="navbar-nav ms-auto mb-2 mb-lg-0">
                <li class="nav-item position-relative">
                    <a class="nav-link" href="<?php echo e(route('cart')); ?>">
                        <i class="fa-solid fa-shopping-cart"></i>
                        <span id="cart-count" class="badge bg-danger badge-sm"><?php echo e(Helper::cartCount()); ?></span>
                    </a>
                </li>
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button"
                        data-bs-toggle="dropdown" aria-expanded="false">
                        <i class="fa-solid fa-user"></i>
                    </a>
                    <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="userDropdown">
                        <?php if(auth()->guard()->check()): ?>
                            <?php if(Auth::user()->role == 'admin'): ?>
                                <li><a class="dropdown-item" href="<?php echo e(route('admin')); ?>" target="_blank">Admin Dashboard</a>
                                </li>
                            <?php else: ?>
                                <li><a class="dropdown-item" href="<?php echo e(route('user')); ?>">Akun Saya</a></li>
                            <?php endif; ?>
                            <li><a class="dropdown-item" href="<?php echo e(route('user.logout')); ?>">Keluar</a></li>
                        <?php else: ?>
                            <li><a class="dropdown-item" href="<?php echo e(route('login.form')); ?>">Masuk</a></li>
                            <li><a class="dropdown-item" href="<?php echo e(route('register.form')); ?>">Daftar</a></li>
                        <?php endif; ?>
                    </ul>
                </li>
            </ul>
        </div>
    </div>
</nav>

<style>
    .logo-img {
        height: 30px;
        width: auto;
    }

    .badge-sm {
        font-size: 0.6rem;
        padding: 0.2em 0.4em;
    }

    @media (max-width: 991px) {
        .navbar-collapse {
            background-color: white;
            padding: 1rem;
            border-radius: 0.5rem;
            box-shadow: 0 0.5rem 1rem rgba(0, 0, 0, 0.15);
            margin-top: 0.5rem;
        }

        .navbar-nav .nav-item {
            border-bottom: 1px solid #f8f9fa;
            padding: 0.5rem 0;
        }

        .navbar-nav .nav-item:last-child {
            border-bottom: none;
        }

        .navbar-nav .nav-link {
            padding: 0.5rem 0;
            display: flex;
            align-items: center;
        }

        .navbar-nav .dropdown-menu {
            border: none;
            box-shadow: none;
        }

        .navbar-nav .dropdown-item {
            padding: 0.5rem 1rem;
        }
    }

    .nav-link.active {
        font-weight: 600;
        color: #000 !important;
    }

    .nav-link:hover {
        color: #000 !important;
    }
</style>
<?php /**PATH /Users/rioanggoro/Documents/kerjaan/ecomerce-laravel-fashion/resources/views/frontend/layouts/header.blade.php ENDPATH**/ ?>
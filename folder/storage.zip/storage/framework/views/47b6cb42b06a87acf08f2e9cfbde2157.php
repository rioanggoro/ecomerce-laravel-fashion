<?php if(session('success')): ?>
    <div class="alert alert-success alert-dismissible fade show text-center" role="alert">
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        <?php echo e(session('success')); ?>

    </div>
<?php endif; ?>

<?php if(session('error')): ?>
    <div class="alert alert-danger alert-dismissible fade show text-center" role="alert">
        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        <?php echo e(session('error')); ?>

    </div>
<?php endif; ?>
<?php /**PATH /Users/rioanggoro/Documents/kerjaan/ecomerce-laravel-fashion/resources/views/frontend/layouts/notification.blade.php ENDPATH**/ ?>
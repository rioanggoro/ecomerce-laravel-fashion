<?php $__env->startSection('title', 'E-SHOP || PRODUCT PAGE'); ?>

<?php $__env->startSection('main-content'); ?>

    <form action="<?php echo e(route('shop.filter')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <section class="product-area shop-sidebar shop-list section py-5">
            <div class="container">
                <div class="row">
                    <div class="col-lg-3 col-md-4 col-12">
                        <div class="shop-sidebar">
                            <h2>Products</h2>
                            <hr>
                            <!-- Single Widget -->
                            <div class="single-widget category">
                                <ul class="list-unstyled mt-4">
                                    <?php
                                        $menu = App\Models\Category::getAllParentWithChild();
                                    ?>
                                    <?php if($menu): ?>
                                        <?php $__currentLoopData = $menu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat_info): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li class="fs-3">
                                                <?php if($cat_info->child_cat->count() > 0): ?>
                                                    <a href="<?php echo e(route('product-cat', $cat_info->slug)); ?>"
                                                        class="text-dark text-decoration-none"><?php echo e($cat_info->title); ?></a>
                                                    <ul class="list-unstyled ms-3">
                                                        <?php $__currentLoopData = $cat_info->child_cat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sub_menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <li><a class="text-dark text-decoration-none"
                                                                    href="<?php echo e(route('product-sub-cat', [$cat_info->slug, $sub_menu->slug])); ?>"><?php echo e($sub_menu->title); ?></a>
                                                            </li>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </ul>
                                                <?php else: ?>
                                                    <a class="text-dark text-decoration-none"
                                                        href="<?php echo e(route('product-cat', $cat_info->slug)); ?>"><?php echo e($cat_info->title); ?></a>
                                                <?php endif; ?>
                                            </li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>
                                </ul>
                            </div>
                            <!--/ End Single Widget -->
                        </div>
                    </div>
                    <div class="col-lg-9 col-md-8 col-12">
                        <div class="row">
                            <?php if(count($products)): ?>
                                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="col-md-4 col-sm-6 product-item mb-4" data-category="<?php echo e($data->cat_id); ?>">
                                        <div class="card h-100">
                                            <?php
                                                $photo = explode(',', $data->photo);
                                            ?>
                                            <a href="<?php echo e(route('product-detail', $data->slug)); ?>">
                                                <img src="<?php echo e($photo[0]); ?>" class="card-img-top"
                                                    alt="<?php echo e($photo[0]); ?>">
                                            </a>
                                            <div class="card-body text-center">
                                                <h5 class="card-title">
                                                    <a href="<?php echo e(route('product-detail', $data->slug)); ?>"
                                                        class="text-decoration-none text-dark"><?php echo e($data->title); ?></a>
                                                </h5>
                                                <p class="text-muted">
                                                    <span
                                                        class="text-decoration-line-through">Rp<?php echo e(number_format($data->price, 2)); ?></span>
                                                    <span
                                                        class="fw-bold text-danger">Rp<?php echo e(number_format($data->price - ($data->discount * $data->price) / 100, 2)); ?></span>
                                                </p>
                                                <div class="btn-group" role="group">
                                                    <a href="<?php echo e(route('add-to-wishlist', $data->slug)); ?>"
                                                        class="btn btn-outline-danger"><i class="fa fa-heart"></i></a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php else: ?>
                                <h4 class="text-warning text-center w-100">Produk tidak ditemukan.</h4>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </form>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('frontend.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/rioanggoro/Documents/kerjaan/ecomerce-laravel-fashion/resources/views/frontend/pages/product-grids.blade.php ENDPATH**/ ?>